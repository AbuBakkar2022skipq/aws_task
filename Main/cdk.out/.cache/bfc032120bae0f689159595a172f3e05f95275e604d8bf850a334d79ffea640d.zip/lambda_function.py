def lambda_handler(event, context):
    print("Lambda Function Created")
    return